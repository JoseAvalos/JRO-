#if 0

#include "mbed.h"
#include "rtos.h"
#include "EthernetInterface.h"

RawSerial pc(USBTX, USBRX);
EthernetInterface eth;

#define IP_INI          "10.10.50.85";               // IP
#define MASK_INI        "255.255.255.0";           // MASK
#define GATEWAY_INI     "10.10.50.1";           // GATEWAY
const char* IP = IP_INI;               // IP
const char* MASK = MASK_INI;           // MASK
const char* GATEWAY = GATEWAY_INI;           // GATEWAY
    
int main(){
    pc.printf("Initializing network interface...\r\n");
    if (0 == eth.init(IP, MASK, GATEWAY)) {
        // It should always take this path
        do {
            pc.printf("Connecting to network...\r\n");
            if (0 == eth.connect()) {
                pc.printf("Ethernet connected as %s\r\n", eth.getIPAddress());
                Thread::wait(5000);
                pc.printf("lost connection.\r\n");
                eth.disconnect();
            }
            else {
                pc.printf("  ... failed to connect.\r\n");
            }
        } while (1);
    }
    else {
        pc.printf("  ... failed to initialize, rebooting...\r\n");
    }
}

#endif