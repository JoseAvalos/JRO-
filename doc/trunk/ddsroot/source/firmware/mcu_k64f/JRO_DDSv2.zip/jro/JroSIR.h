#ifndef        JRO_SIR
#define        JRO_SIR

//Device commands
#define CMD_RESET       0X01
#define CMD_ENABLE      0x02
#define CMD_CHANGE_IP   0x03

#endif