#ifndef        UTILS_ETH
#define        UTILS_ETH

#include "FreescaleIAP.h"

#define MAX_IP_LEN  16

#define IP_INI          "192.168.7.2";               // IP
#define MASK_INI        "255.255.255.0";           // MASK
#define GATEWAY_INI     "0.0.0.0";                  // GATEWAY
//INTERNAL FLASH
#define FLASH_FULL  0xAA
    
int numberOfDigits(int x);
int isNumber(char* str);
int splitstr(char *, const char *, char parts[][MAX_IP_LEN]);
int validateIp(char* str);
int splitIpConf(char* str, char *_ip, char *_mask, char *_gateway);

int eraseIpConfig();
int saveIpConfig(char *ip, char *mask, char *gateway);
int readIpConfig(char *_ip, char *_mask, char *_gateway);

#endif