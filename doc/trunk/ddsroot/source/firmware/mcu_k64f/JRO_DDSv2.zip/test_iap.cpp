#include "mbed.h"
#include "FreescaleIAP.h"
 
 #if 0
int main() {
    int address = flash_size() - SECTOR_SIZE;           //Write in last sector
    
    int *data = (int*)address;
    char *data_str = (char*)address;
    printf("Starting\r\n"); 
    erase_sector(address);
    int numbers[10] = {0, 1, 10, 100, 1000, 10000, 1000000, 10000000, 100000000, 1000000000};
    char *ip = "a12b3c4d5";
    //program_flash(address, (char*)&numbers, 40);        //10 integers of 4 bytes each: 40 bytes length
    program_flash(address, ip, strlen(ip));                     //15 chars of 4 bytes each: 60 bytes length
    printf("Resulting flash: \r\n");
    //for (int i = 0; i<10; i++)
        //printf("%d\r\n", data[i]);
    //
    printf("%s\r\n", data_str);
    printf("Done\r\n\n");
        
 
    while (true) {
    }
}
#endif